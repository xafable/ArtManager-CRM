require('./bootstrap');
require("node_modules/bootstrap-css-only/css/bootstrap.min.css");
require("node_modules/mdbvue/lib/css/mdb.min.css");
require("node_modules/@fortawesome/fontawesome-free/css/all.min.css");
